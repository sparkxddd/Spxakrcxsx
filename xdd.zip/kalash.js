module.exports = {
  token: process.env.token,
  port: "3000",
  prefix: "..",
  client: "1066128055476695090",
  client_id: "1075489796555812925",
  client_secret: "mJ0JWJ646paI2issQgpBsKtDfd1j6Lci",
  redirect_uri: "https://xdd.keremrxd.repl.co",
  footer: "Verification",
  support: "",
  wehbook: process.env.webhook, //wehbook de logs
  owners: ["1066128055476695090", "324814243822305282"],
  authLink: `https://discord.com/api/oauth2/authorize?client_id=1081935854295077055&redirect_uri=https%3A%2F%2Fauthbot.keremrxd.repl.co&response_type=code&scope=guilds.join%20identify`,

}
